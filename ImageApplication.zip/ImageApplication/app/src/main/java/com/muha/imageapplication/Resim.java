package com.muha.imageapplication;

public class Resim {


    private int Id;
    private String resimBaslik;
    private int resim;


    public Resim() {
    }

    public Resim(int Id, String resimBaslik, int resim) {
        this.Id = Id;
        this.resimBaslik = resimBaslik;
        this.resim = resim;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getResimBaslik() {
        return resimBaslik;
    }

    public void setResimBaslik(String resimBaslik) {
        this.resimBaslik = resimBaslik;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
