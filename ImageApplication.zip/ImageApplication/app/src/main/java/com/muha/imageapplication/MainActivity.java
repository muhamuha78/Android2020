package com.muha.imageapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.QuickContactBadge;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView ivresim;
    TextView tvBaslik;
    Button btnileri,btngeri,btnrasgele;

    int sayi=0;
    ArrayList<Resim> resimler =new ArrayList<>();
    Random rasgele  = new Random();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivresim=findViewById(R.id.ivresim);
        tvBaslik=findViewById(R.id.tvBaslik);
        btngeri=findViewById(R.id.btnGeri);
        btnileri=findViewById(R.id.btnileri);
        btnrasgele=findViewById(R.id.btnrasgele);

        //public Resim(int Id, String resimBaslik, int resim)
        resimler.add(new Resim(1, "Başlık 1",R.drawable.resim1));
        resimler.add(new Resim(2, "Başlık 2",R.drawable.resim2));
        resimler.add(new Resim(3, "Başlık 3",R.drawable.resim3));
        resimler.add(new Resim(4, "Başlık 4",R.drawable.resim4));
        resimler.add(new Resim(5, "Başlık 5",R.drawable.resim5));
        resimler.add(new Resim(6, "Başlık 6",R.drawable.resim6));


        btnrasgele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayi= rasgele.nextInt(resimler.size());
                ivresim.setImageResource(resimler.get(sayi).getResim());
                tvBaslik.setText(resimler.get(sayi).getResimBaslik());
            }
        });
        btngeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sayi != 0) {
                    sayi--;
                    ivresim.setImageResource(resimler.get(sayi).getResim());
                    tvBaslik.setText(resimler.get(sayi).getResimBaslik());
                }
            }
        });
        btnileri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sayi<resimler.size()-1) {
                    sayi++;
                    ivresim.setImageResource(resimler.get(sayi).getResim());
                    tvBaslik.setText(resimler.get(sayi).getResimBaslik());//kod ile textview nesnesinin görünen yazısını değiştir
                }
            }
        });


    }
}
